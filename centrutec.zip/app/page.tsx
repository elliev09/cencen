import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ChevronRight, Mail, MapPin, Phone, Star } from "lucide-react"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Image
              src="/placeholder.svg?height=32&width=32"
              alt="Centrutec Logo"
              width={32}
              height={32}
              className="rounded-md bg-blue-600 p-1"
            />
            <span className="text-xl font-bold">Centrutec</span>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
              Inicio
            </Link>
            <Link href="#productos" className="text-sm font-medium hover:underline underline-offset-4">
              Productos
            </Link>
            <Link href="#nosotros" className="text-sm font-medium hover:underline underline-offset-4">
              Nosotros
            </Link>
            <Link href="#servicios" className="text-sm font-medium hover:underline underline-offset-4">
              Servicios
            </Link>
            <Link href="#contacto" className="text-sm font-medium hover:underline underline-offset-4">
              Contacto
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" className="hidden md:flex">
              Iniciar Sesión
            </Button>
            <Button size="sm">Contactar</Button>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-blue-50 to-white">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Soluciones tecnológicas para el mundo moderno
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Distribuidores oficiales de las mejores marcas en tecnología y electrónica. Calidad y servicio
                    garantizado.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button size="lg">
                    Ver catálogo
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="lg">
                    Conocer más
                  </Button>
                </div>
              </div>
              <Image
                src="/placeholder.svg?height=550&width=550"
                alt="Productos electrónicos"
                width={550}
                height={550}
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover sm:w-full lg:order-last"
              />
            </div>
          </div>
        </section>

        <section id="productos" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-blue-100 px-3 py-1 text-sm text-blue-900">
                  Productos Destacados
                </div>
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Tecnología de vanguardia</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Ofrecemos una amplia gama de productos electrónicos de las mejores marcas del mercado.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
              {[
                {
                  title: "Laptops y Computadoras",
                  description: "Equipos de última generación para profesionales y gamers.",
                  image: "/placeholder.svg?height=200&width=300",
                },
                {
                  title: "Smartphones",
                  description: "Los últimos modelos con la mejor tecnología móvil.",
                  image: "/placeholder.svg?height=200&width=300",
                },
                {
                  title: "Accesorios",
                  description: "Complementos esenciales para tus dispositivos.",
                  image: "/placeholder.svg?height=200&width=300",
                },
                {
                  title: "Smart Home",
                  description: "Dispositivos para hacer tu hogar más inteligente.",
                  image: "/placeholder.svg?height=200&width=300",
                },
                {
                  title: "Audio y Video",
                  description: "Experiencia audiovisual de alta calidad.",
                  image: "/placeholder.svg?height=200&width=300",
                },
                {
                  title: "Componentes",
                  description: "Piezas y repuestos originales garantizados.",
                  image: "/placeholder.svg?height=200&width=300",
                },
              ].map((product, index) => (
                <Card key={index} className="group relative overflow-hidden rounded-lg border">
                  <CardHeader className="p-0">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.title}
                      width={300}
                      height={200}
                      className="w-full object-cover transition-transform group-hover:scale-105"
                    />
                  </CardHeader>
                  <CardContent className="p-4">
                    <CardTitle>{product.title}</CardTitle>
                    <CardDescription>{product.description}</CardDescription>
                  </CardContent>
                  <CardFooter className="p-4 pt-0">
                    <Button variant="outline" size="sm" className="w-full">
                      Ver productos
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section id="nosotros" className="w-full py-12 md:py-24 lg:py-32 bg-blue-50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Equipo Centrutec"
                width={600}
                height={400}
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover"
              />
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <div className="inline-block rounded-lg bg-blue-100 px-3 py-1 text-sm text-blue-900">
                    Sobre Nosotros
                  </div>
                  <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Más de 15 años de experiencia</h2>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Centrutec nació en 2008 con la misión de ofrecer productos tecnológicos de calidad a precios
                    competitivos.
                  </p>
                </div>
                <ul className="grid gap-2">
                  {[
                    "Distribuidores oficiales de más de 50 marcas reconocidas",
                    "Equipo de especialistas certificados",
                    "Garantía extendida en todos nuestros productos",
                    "Servicio técnico especializado",
                    "Envíos a todo el país",
                  ].map((item, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-white">
                        <ChevronRight className="h-4 w-4" />
                      </div>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <div>
                  <Button>Conoce nuestra historia</Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="servicios" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-blue-100 px-3 py-1 text-sm text-blue-900">
                  Nuestros Servicios
                </div>
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">
                  Soluciones integrales para tu negocio
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Además de distribución, ofrecemos servicios especializados para empresas y particulares.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 py-12 md:grid-cols-2 lg:grid-cols-3">
              {[
                {
                  title: "Asesoría Técnica",
                  description: "Consultoría especializada para implementación de soluciones tecnológicas.",
                },
                {
                  title: "Mantenimiento",
                  description: "Servicio técnico preventivo y correctivo para tus equipos.",
                },
                {
                  title: "Instalación",
                  description: "Configuración profesional de equipos y redes.",
                },
                {
                  title: "Capacitación",
                  description: "Formación para el uso óptimo de herramientas tecnológicas.",
                },
                {
                  title: "Soporte Empresarial",
                  description: "Atención prioritaria para clientes corporativos.",
                },
                {
                  title: "Desarrollo a Medida",
                  description: "Soluciones personalizadas según tus necesidades específicas.",
                },
              ].map((service, index) => (
                <div key={index} className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
                    <div className="h-6 w-6 text-blue-700">
                      {index % 6 === 0 && <Star className="h-6 w-6" />}
                      {index % 6 === 1 && <Phone className="h-6 w-6" />}
                      {index % 6 === 2 && <Mail className="h-6 w-6" />}
                      {index % 6 === 3 && <MapPin className="h-6 w-6" />}
                      {index % 6 === 4 && <Star className="h-6 w-6" />}
                      {index % 6 === 5 && <Phone className="h-6 w-6" />}
                    </div>
                  </div>
                  <h3 className="text-xl font-bold">{service.title}</h3>
                  <p className="text-center text-muted-foreground">{service.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-blue-600 text-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Marcas que distribuimos</h2>
                <p className="max-w-[900px] text-blue-100 md:text-xl">
                  Trabajamos con los fabricantes más reconocidos del mercado.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-2 gap-8 py-12 md:grid-cols-4 lg:grid-cols-6">
              {Array.from({ length: 12 }).map((_, index) => (
                <div key={index} className="flex items-center justify-center">
                  <div className="h-16 w-16 rounded-full bg-white p-2">
                    <Image
                      src="/placeholder.svg?height=60&width=60"
                      alt={`Marca ${index + 1}`}
                      width={60}
                      height={60}
                      className="h-full w-full object-contain"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-blue-100 px-3 py-1 text-sm text-blue-900">Testimonios</div>
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Lo que dicen nuestros clientes</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  La satisfacción de nuestros clientes es nuestra mejor carta de presentación.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
              {[
                {
                  name: "Carlos Rodríguez",
                  company: "TechSolutions S.A.",
                  testimonial:
                    "Centrutec ha sido nuestro proveedor de confianza durante más de 5 años. Su servicio y calidad son excepcionales.",
                },
                {
                  name: "María González",
                  company: "Innovación Digital",
                  testimonial:
                    "El soporte técnico que ofrecen es de primer nivel. Siempre resuelven nuestras dudas de manera rápida y eficiente.",
                },
                {
                  name: "Javier Méndez",
                  company: "Grupo Empresarial XYZ",
                  testimonial:
                    "Gracias a su asesoría pudimos implementar la infraestructura tecnológica ideal para nuestras necesidades.",
                },
              ].map((testimonial, index) => (
                <Card key={index} className="text-center">
                  <CardHeader>
                    <div className="flex justify-center">
                      <div className="flex">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star key={i} className="h-5 w-5 fill-current text-yellow-500" />
                        ))}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">"{testimonial.testimonial}"</p>
                  </CardContent>
                  <CardFooter className="flex flex-col">
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.company}</p>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section id="contacto" className="w-full py-12 md:py-24 lg:py-32 bg-blue-50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <div className="inline-block rounded-lg bg-blue-100 px-3 py-1 text-sm text-blue-900">Contacto</div>
                  <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">¿Necesitas más información?</h2>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Estamos aquí para ayudarte. Completa el formulario y nos pondremos en contacto contigo a la
                    brevedad.
                  </p>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-blue-600" />
                    <span>Av. Tecnológica 1234, Ciudad Innovación</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-5 w-5 text-blue-600" />
                    <span>+123 456 7890</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="h-5 w-5 text-blue-600" />
                    <span>info@centrutec.com</span>
                  </div>
                </div>
              </div>
              <div className="rounded-lg border bg-background p-6 shadow-sm">
                <form className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label
                        htmlFor="nombre"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Nombre
                      </label>
                      <Input id="nombre" placeholder="Tu nombre" />
                    </div>
                    <div className="space-y-2">
                      <label
                        htmlFor="apellido"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Apellido
                      </label>
                      <Input id="apellido" placeholder="Tu apellido" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label
                      htmlFor="email"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Correo electrónico
                    </label>
                    <Input id="email" type="email" placeholder="tu@email.com" />
                  </div>
                  <div className="space-y-2">
                    <label
                      htmlFor="telefono"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Teléfono
                    </label>
                    <Input id="telefono" placeholder="+123 456 7890" />
                  </div>
                  <div className="space-y-2">
                    <label
                      htmlFor="mensaje"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Mensaje
                    </label>
                    <Textarea id="mensaje" placeholder="¿En qué podemos ayudarte?" className="min-h-[120px]" />
                  </div>
                  <Button type="submit" className="w-full">
                    Enviar mensaje
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t bg-background">
        <div className="container flex flex-col gap-6 py-12 md:flex-row md:gap-8 md:py-16">
          <div className="flex flex-col gap-3 md:w-1/3">
            <div className="flex items-center gap-2">
              <Image
                src="/placeholder.svg?height=32&width=32"
                alt="Centrutec Logo"
                width={32}
                height={32}
                className="rounded-md bg-blue-600 p-1"
              />
              <span className="text-xl font-bold">Centrutec</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Distribuidores oficiales de tecnología y electrónica. Calidad y servicio garantizado desde 2008.
            </p>
          </div>
          <div className="grid flex-1 grid-cols-2 gap-8 sm:grid-cols-4">
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Productos</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Laptops
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Smartphones
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Accesorios
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Smart Home
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Servicios</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Asesoría
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Mantenimiento
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Instalación
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Capacitación
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Empresa</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Sobre Nosotros
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Clientes
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Trabaja con nosotros
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Blog
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Legal</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Términos
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Privacidad
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Cookies
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Licencias
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="border-t py-6">
          <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
            <p className="text-center text-sm text-muted-foreground md:text-left">
              © 2023 Centrutec. Todos los derechos reservados.
            </p>
            <div className="flex gap-4">
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <span className="sr-only">Facebook</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <span className="sr-only">Twitter</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                </svg>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <span className="sr-only">Instagram</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                </svg>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <span className="sr-only">LinkedIn</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                  <rect x="2" y="9" width="4" height="12"></rect>
                  <circle cx="4" cy="4" r="2"></circle>
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
